# stack
create a stack with registries and ressource groups 
